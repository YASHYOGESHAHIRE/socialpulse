import mistune
markdown_text = """
## **Statistical Analysis of All Post Types**

### **Overall Summary**
- **Total Records:** 50
- **Post Types:** Carousel, Reel, Static

### **Table 1: Summary Statistics by Post Type**
| **Post Type** | **Count** | **Average Likes** | **Average Shares** | **Average Comments** |
|---------------|----------:|-----------------:|------------------:|-------------------:|
| **Carousel**  | 20        | 333.55            | 103.1              | 60.55              |
| **Reel**      | 14        | 487.21            | 178.5              | 112.79             |
| **Static**    | 16        | 122.56            | 27.56              | 21.56              |
"""
def format_to_html(markdown_text: str) -> str:
    # Initialize the Markdown parser
    markdown_parser = mistune.create_markdown()
    # Convert Markdown to HTML
    html = markdown_parser(markdown_text)
    return html

# Example
html_output = format_to_html(markdown_text)
print(html_output)
