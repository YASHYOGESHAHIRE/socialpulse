from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import requests
import json
from typing import Optional
import os
import mistune
import warnings

# FastAPI app initialization
app = FastAPI()

# Template directory for UI
templates = Jinja2Templates(directory="templates")

# API Configuration for Run Flow
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()

# Retrieve sensitive information from environment variables
BASE_API_URL_CHATBOT = os.getenv("BASE_API_URL_CHATBOT")
LANGFLOW_ID_CHATBOT = os.getenv("LANGFLOW_ID_CHATBOT")
FLOW_ID_CHATBOT = os.getenv("FLOW_ID_CHATBOT")
APPLICATION_TOKEN_CHATBOT = os.getenv("APPLICATION_TOKEN_CHATBOT")

TWEAKS_CHATBOT = {
 "ChatInput-aTJJ5": {},
  "ParseData-nIniJ": {},
  "Prompt-gb7oz": {},
  "SplitText-kaAR9": {},
  "AstraDB-9Pnhv": {},
  "AstraDB-h14lK": {},
  "File-Zx63C": {},
  "Google Generative AI Embeddings-RToWW": {},
  "Google Generative AI Embeddings-FEZo0": {},
  "ChatOutput-xdYQK": {},
  "GroqModel-up2tQ": {}
}

# Function to run LangFlow API call (Run Flow)
def run_flow(
    message: str,
    endpoint: str,
    output_type: str = "chat",
    input_type: str = "chat",
    tweaks: Optional[dict] = None,
    application_token: Optional[str] = None
) -> dict:
    api_url = f"{BASE_API_URL_CHATBOT}/lf/{LANGFLOW_ID_CHATBOT}/api/v1/run/{endpoint}"

    payload = {
        "input_value": message,
        "output_type": output_type,
        "input_type": input_type,
    }
    if tweaks:
        payload["tweaks"] = tweaks

    headers = {"Authorization": f"Bearer {application_token}", "Content-Type": "application/json"} if application_token else None

    try:
        response = requests.post(api_url, json=payload, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"HTTP Request failed: {e}")
        return {"error": str(e), "outputs": []}

    try:
        return response.json()
    except json.JSONDecodeError:
        print("JSON decoding failed. Response content:", response.text)
        return {"error": "Invalid JSON response", "outputs": []}
@app.get("/chart", response_class=HTMLResponse)
async def get_dashboard(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
@app.get("/", response_class=HTMLResponse)
async def get_dashboard(request: Request):
    return templates.TemplateResponse("homepage.html", {"request": request})


@app.get("/dashboard", response_class=HTMLResponse)
def show_dashboard():
    with open("templates/dashboard.html", "r", encoding="utf-8") as f:
        html_content = f.read()
    return HTMLResponse(content=html_content, status_code=200)
# Function to run Chatbot API call
def run_chatbot_flow(
    message: str,
    endpoint: str,
    output_type: str = "chat",
    input_type: str = "chat",
    tweaks: Optional[dict] = None,
    application_token: Optional[str] = None
) -> dict:
    api_url = f"{BASE_API_URL_CHATBOT}/lf/{LANGFLOW_ID_CHATBOT}/api/v1/run/{endpoint}"

    payload = {
        "input_value": message,
        "output_type": output_type,
        "input_type": input_type,
    }
    if tweaks:
        payload["tweaks"] = tweaks

    headers = {"Authorization": f"Bearer {application_token}", "Content-Type": "application/json"} if application_token else None

    try:
        response = requests.post(api_url, json=payload, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"HTTP Request failed: {e}")
        return {"error": str(e), "outputs": []}

    try:
        return response.json()
    except json.JSONDecodeError:
        print("JSON decoding failed. Response content:", response.text)
        return {"error": "Invalid JSON response", "outputs": []}

# Route for chatbot page
@app.get("/chatbot", response_class=HTMLResponse)
async def get_chatbot_page(request: Request):
    return templates.TemplateResponse("chatbot.html", {"request": request})

# Route to handle chat-response for chatbot API
@app.post("/chat-response/")
async def chat_response(
    request: Request,
    input_type: Optional[str] = Form(""),
    user_message: str = Form(...),
):
    input_message = f"{user_message} | Details: | POST type: {input_type} "
                   

    response_data = run_chatbot_flow(
        message=input_message,
        endpoint=FLOW_ID_CHATBOT,
        tweaks=TWEAKS_CHATBOT,
        application_token=APPLICATION_TOKEN_CHATBOT
    )

    chat_response_text = "No response available."
    if "error" in response_data:
        chat_response_text = response_data["error"]
    elif "outputs" in response_data and isinstance(response_data["outputs"], list):
        outputs = response_data["outputs"][0]
        if "outputs" in outputs and isinstance(outputs["outputs"], list):
            inner_output = outputs["outputs"][0]
            chat_response_text = inner_output["results"].get("message", {}).get("text", "No content returned")

 
    
    return templates.TemplateResponse("chatbot.html", {
        "request": request,
        "chat_response": chat_response_text,
        "user_message": user_message
    })

# API endpoint to handle form submission for Run Flow
@app.post("/run-flow/")
async def run_flow_endpoint(request: Request, input_type: str = Form(...), additional_message: str = Form("")):
    dashboard_file_path = "templates/dashboard.html"

    input_message = (
        f"Retrieve max 5 rows for this purpose choose it wisely, Give me HTML, CSS, and JavaScript code without direct line breaks, which will create two-three charts and proper insights from dataset, making the whole dashboard visually appealing. Provide complete code. POST type: {input_type}. {additional_message}. "
        "GIVE DIRECT EXECUTABLE CODE WITH NO ERRORS OR INCOMPLETIONS. Retrieve required rows directly into frontend to create charts"
    )

    response_data = run_flow(
        message=input_message,
        endpoint=FLOW_ID_CHATBOT,
        tweaks=TWEAKS_CHATBOT,
        application_token=APPLICATION_TOKEN_CHATBOT
    )

    html_code_only = None

    if "error" in response_data:
        return templates.TemplateResponse("index.html", {"request": request, "html_code_only": None, "input_type": input_type, "error_message": response_data["error"]})

    if "outputs" in response_data and isinstance(response_data["outputs"], list):
        outputs = response_data["outputs"][0]
        if "outputs" in outputs and isinstance(outputs["outputs"], list):
            inner_output = outputs["outputs"][0]
            answer = inner_output["results"].get("message", {}).get("text", "")
            print(answer)
            html_start = answer.find("<html>")
            html_end = answer.find("</html>") + len("</html>")
            html_code_only = answer[html_start:html_end]
            print(html_code_only)
            if html_code_only:
                with open(dashboard_file_path, "w", encoding="utf-8") as f:
                    f.write(html_code_only)

    return templates.TemplateResponse("index.html", {"request": request, "html_code_only": html_code_only, "input_type": input_type})


